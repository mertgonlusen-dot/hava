# HVAC Compare

Evidence-backed HVAC competitor comparison MVP.

## Live-demo readiness

The current v0.1 runs entirely on bundled demo data, so **no database or API key is required to deploy and test the user interface on Vercel**.

### One-click-ish deployment path

1. Put the contents of this repository into a GitHub repository.
2. In Vercel select **Add New -> Project**.
3. Import that GitHub repository.
4. Accept the detected Next.js settings.
5. Click **Deploy**.

See [`DEPLOY_TO_VERCEL.md`](./DEPLOY_TO_VERCEL.md) for mobile-friendly instructions.

## What already works

- Responsive web UI
- Daikin source-product selection
- Samsung / Mitsubishi Electric candidate matching
- Deterministic engineering-weighted scoring
- Parameter-by-parameter provenance display
- Verification statuses and explicit unknowns
- XLSX export with evidence + match logic tabs
- REST comparison endpoint
- Supabase/Postgres production schema
- OpenAI provider abstraction for future evidence-constrained narratives
- Matching unit tests

> **Data warning:** The bundled technical values and model names are illustrative placeholders. They exist only to exercise the product workflow. Do not use them for engineering, sales, tender or customer claims. Replace them with verified manufacturer sources.

## Run locally

```bash
npm install
npm run dev
```

Open <http://localhost:3000>.

## Test

```bash
npm test
```

## Production build

```bash
npm run build
```

## Recommended next work

1. Build 20-30 engineer-approved golden pairs.
2. Replace demo data with verified public source records.
3. Move data access from `lib/data/demo-products.ts` to Supabase.
4. Add an admin review queue for document extraction.
5. Add document-level source URLs/files and page previews.
6. Calibrate scoring weights from golden-pair accuracy.
7. Add role-based internal vs customer-facing exports.

See `/docs` for the PRD, architecture, ontology, matching rules and data/legal design policy.
