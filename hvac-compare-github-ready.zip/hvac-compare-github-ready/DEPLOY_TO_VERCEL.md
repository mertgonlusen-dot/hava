# Deploy HVAC Compare to Vercel

This repository is ready for a standard Vercel deployment.

## Fastest route: GitHub -> Vercel

1. Create a new GitHub repository, e.g. `hvac-compare`.
2. Upload the **contents of this folder** to the repository root.
   - `package.json` must be at the root of the repo.
   - Do not upload the enclosing ZIP as a single file.
3. In Vercel choose **Add New -> Project**.
4. Import the GitHub repository.
5. Vercel should detect **Next.js** automatically.
6. Keep the default settings and click **Deploy**.

No environment variables are required for the current demo version.

## Important

The current product/model data is illustrative demo data only. Do not use it for real technical, engineering, sales, tender, or customer claims.

## Later environment variables

When Supabase and AI document ingestion are enabled, configure these in Vercel Project Settings -> Environment Variables:

- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- `SUPABASE_SERVICE_ROLE_KEY`
- `OPENAI_API_KEY`

These are not required to test v0.1.
