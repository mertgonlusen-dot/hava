import { NextRequest, NextResponse } from 'next/server';
import { compareProduct } from '@/lib/matching/engine';

export async function GET(req:NextRequest) {
  const sourceId=req.nextUrl.searchParams.get('sourceId');
  const manufacturer=req.nextUrl.searchParams.get('manufacturer') ?? undefined;
  if(!sourceId) return NextResponse.json({error:'sourceId is required'},{status:400});
  try { return NextResponse.json({results:compareProduct(sourceId,manufacturer)}); }
  catch(e) { return NextResponse.json({error:e instanceof Error?e.message:'Unknown error'},{status:404}); }
}
