import { NextRequest, NextResponse } from 'next/server';
import { compareProduct } from '@/lib/matching/engine';
import { buildComparisonWorkbook } from '@/lib/export/workbook';

export async function GET(req:NextRequest) {
  const sourceId=req.nextUrl.searchParams.get('sourceId'); const candidateId=req.nextUrl.searchParams.get('candidateId');
  if(!sourceId||!candidateId) return NextResponse.json({error:'sourceId and candidateId required'},{status:400});
  const result=compareProduct(sourceId).find(r=>r.candidate.id===candidateId); if(!result) return NextResponse.json({error:'Comparison not found'},{status:404});
  const buffer=await buildComparisonWorkbook(result);
  return new NextResponse(buffer as BodyInit,{headers:{'Content-Type':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','Content-Disposition':'attachment; filename="hvac-comparison.xlsx"'}});
}
