import './globals.css';
import Link from 'next/link';

export const metadata = {
  title: 'HVAC Compare',
  description: 'Evidence-backed HVAC competitor comparisons.'
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>
        <div className="shell">
          <nav className="nav">
            <Link href="/" className="brand">HVAC<span>Compare</span></Link>
            <div className="navlinks">
              <Link href="/compare">Compare</Link>
              <Link href="/products">Products</Link>
              <a href="https://github.com" target="_blank" rel="noreferrer">Repository</a>
            </div>
          </nav>
          {children}
          <div className="footer">Prototype v0.1 · Demo technical data is illustrative until replaced with verified manufacturer sources.</div>
        </div>
      </body>
    </html>
  );
}
