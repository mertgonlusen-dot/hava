import Link from 'next/link';
import { demoProducts } from '@/lib/data/demo-products';

export default function Home() {
  const brands = new Set(demoProducts.map(p => p.manufacturer)).size;
  const verified = demoProducts.flatMap(p => p.parameters).filter(x => x.status === 'VERIFIED').length;
  return (
    <main>
      <section className="hero">
        <span className="badge">Evidence-first competitor intelligence</span>
        <h1>HVAC comparison without pretending to know what you cannot verify.</h1>
        <p>Find the closest technical equivalent, inspect the engineering logic, see the source behind each parameter, and export a comparison worksheet. This MVP keeps AI out of the decision core and treats missing data as a first-class result.</p>
        <div style={{display:'flex', gap:10, marginTop:22}}>
          <Link className="cta" href="/compare">Run a comparison →</Link>
          <Link className="cta secondary" href="/products">Browse seed data</Link>
        </div>
      </section>
      <section className="grid" style={{marginTop:28}}>
        <div className="card kpi"><div className="muted">Seed products</div><div className="num">{demoProducts.length}</div><div className="muted">Illustrative MVP records</div></div>
        <div className="card kpi"><div className="muted">Manufacturers</div><div className="num">{brands}</div><div className="muted">Daikin + competitor demo set</div></div>
        <div className="card kpi"><div className="muted">Evidence-linked values</div><div className="num">{verified}</div><div className="muted">Demo provenance objects</div></div>
      </section>
      <section className="card" style={{marginTop:16}}>
        <h2>How the engine thinks</h2>
        <div className="grid">
          {[
            ['1. Filter', 'Same product class, application, market and sensible capacity band.'],
            ['2. Score', 'Deterministic weighted engineering rules — no LLM guess decides equivalence.'],
            ['3. Evidence', 'Every parameter carries condition, source, page and verification status.'],
            ['4. Export', 'Generate a comparison workbook that separates facts, assumptions and unknowns.']
          ].map(([t,d]) => <div key={t} style={{gridColumn:'span 6'}}><h3>{t}</h3><p className="muted">{d}</p></div>)}
        </div>
      </section>
      <div className="notice" style={{marginTop:16}}><strong>Important:</strong> the bundled product values are deliberately marked as illustrative. Replace them with validated public manufacturer documents before any commercial or customer-facing use.</div>
    </main>
  );
}
