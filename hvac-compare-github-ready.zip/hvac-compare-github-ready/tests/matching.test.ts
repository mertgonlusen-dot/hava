import assert from 'node:assert/strict';
import test from 'node:test';
import { compareProduct, eligibleCandidates } from '../lib/matching/engine';
import { demoProducts } from '../lib/data/demo-products';

test('candidate filter excludes same manufacturer and wrong size band',()=>{
  const source=demoProducts.find(p=>p.id==='d-rzag100-fba100')!;
  const candidates=eligibleCandidates(source);
  assert.ok(candidates.every(c=>c.manufacturer!=='Daikin'));
  assert.ok(candidates.every(c=>c.indoorType==='DUCTED'));
});

test('Samsung 10 kW candidate ranks above 12 kW candidate for 9.5 kW source',()=>{
  const results=compareProduct('d-rzag100-fba100','Samsung');
  assert.equal(results[0].candidate.id,'s-cdx100-d');
  assert.ok(results[0].score>results[1].score);
});

test('match factors add to declared weight set',()=>{
  const result=compareProduct('d-rzag100-fba100','Samsung')[0];
  const total=result.factors.reduce((s,f)=>s+f.weight,0);
  assert.ok(Math.abs(total-1)<0.0001);
});
