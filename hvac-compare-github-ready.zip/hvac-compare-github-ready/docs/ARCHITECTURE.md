# Architecture

## Principle
The product is not an LLM wrapper. The durable asset is a normalized HVAC product/evidence graph plus versioned engineering rules.

## Flow
1. Manufacturer/public documents
2. AI-assisted extraction into staging
3. Human validation
4. Structured product database
5. Deterministic candidate filtering
6. Deterministic weighted match score
7. Evidence-backed comparison
8. Optional LLM narrative constrained to supplied evidence
9. Excel/customer output

## Production stack
- Next.js 16 / TypeScript
- PostgreSQL / Supabase
- Object storage for source PDFs
- OpenAI Responses API behind an internal provider interface
- ExcelJS for workbook exports

## Trust boundaries
- VERIFIED: manually reviewed against source.
- CALCULATED: deterministic formula with explicit inputs.
- USER_PROVIDED: uploaded by an authorized user.
- INFERRED: model/logic inference; never silently promoted to verified.
- UNKNOWN: insufficient evidence.

## Future ingestion pipeline
Document -> hash -> metadata -> chunk/page extraction -> structured candidate JSON -> validation rules -> review queue -> publish.
