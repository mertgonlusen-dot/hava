# Matching Rules v0

Candidate filter:
- Different manufacturer
- Same category
- Same indoor type
- Same market
- Nominal cooling capacity within -20% / +25%

Score weights:
- Capacity class: 22%
- Application: 15%
- Indoor type: 12%
- Refrigerant: 10%
- Operating envelope: 13%
- Seasonal efficiency: 10%
- Piping: 6%
- Acoustics: 5%
- ESP: 7%

These are starting hypotheses, not engineering truth. Calibrate them against the golden-pair dataset and keep versions so historical comparisons remain reproducible.
