# Data & Legal Design Policy

This document is product-design guidance, not legal advice.

1. Prefer official public manufacturer sources and data the customer is authorized to use.
2. Do not bypass access controls or automate extraction from protected selection tools without permission.
3. Preserve document title, revision, page and rating condition with every important value.
4. Customer-facing exports should default to VERIFIED/CALCULATED/USER_PROVIDED values and clearly label other statuses.
5. Do not generate unsupported claims such as "Brand A is better". Present measurable differences and evidence.
6. Keep source document hashes and revisions so comparisons can be reproduced later.
7. Retain human approval for equivalence rules and high-impact customer-facing templates.
