# HVAC Ontology v0

## Product identity
Manufacturer, family, model, market, category, indoor type, application, lifecycle revision.

## Commercial DX comparison dimensions
- Capacity class
- Application fit
- Indoor unit type
- Refrigerant
- Low/high ambient operating envelope
- Seasonal efficiency
- Piping limitations
- Acoustics
- External static pressure
- Electrical supply
- Controls/BMS (future)
- Dimensions/weight (future)
- Combination constraints (future)

## Rating-condition rule
A numeric performance value without a rating condition must never be assumed to be directly comparable to a value measured under a different or unknown condition.

## Equivalence rule
Equivalence means "closest technical candidate under declared comparison rules". It does not imply identical performance, regulatory equivalence, or commercial superiority.
