# HVAC Compare — Product Requirements Document

## Problem
Sales/application engineers spend substantial time identifying competitor equivalents, checking technical databooks, normalizing terms and building Excel comparisons. The work is repetitive, evidence-heavy and risky when rating conditions differ or source provenance is lost.

## MVP promise
Given a known Commercial DX source product, identify the closest competitor candidate using explicit engineering rules, show a side-by-side evidence-backed comparison, expose missing/unverifiable values, and export the result to Excel.

## Initial scope
- Commercial DX only
- Ducted units first
- Daikin as source brand
- Samsung and Mitsubishi Electric as competitor brands
- EU market
- Public/authorized technical data only

## Non-goals
- No unauthorized scraping of protected selection tools.
- No generation of special-condition performance when manufacturer selection data is unavailable.
- No automatic superiority claims.
- No unreviewed AI extraction becoming production truth.

## Core user stories
1. Search a source model and receive ranked competitor candidates.
2. Understand why candidate A ranks higher than B.
3. Inspect source, revision, page and rating condition for each value.
4. See UNKNOWN instead of a guessed number.
5. Export a clean comparison workbook.
6. Admin uploads technical documents and reviews extracted candidate data (post-MVP).

## MVP acceptance criteria
- Top-1 matching accuracy measured against at least 20 engineer-approved golden pairs.
- Every externally displayed technical value has a verification status.
- Verified values have a source document and page wherever the source format supports pages.
- Matching is deterministic and testable.
- Excel output clearly separates evidence and unknowns.
