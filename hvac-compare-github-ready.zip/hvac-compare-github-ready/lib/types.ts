export type VerificationStatus = 'VERIFIED' | 'CALCULATED' | 'USER_PROVIDED' | 'INFERRED' | 'UNKNOWN';

export type ParameterKey =
  | 'nominal_cooling_kw' | 'nominal_heating_kw' | 'seer' | 'scop'
  | 'heating_min_ambient_c' | 'cooling_max_ambient_c' | 'max_piping_m'
  | 'sound_power_dba' | 'refrigerant' | 'power_supply' | 'max_esp_pa';

export interface EvidenceSource {
  id: string;
  title: string;
  manufacturer: string;
  revision: string;
  page?: number;
  url?: string;
  note?: string;
}

export interface ProductParameter {
  key: ParameterKey;
  label: string;
  value: number | string | null;
  unit?: string;
  condition?: string;
  status: VerificationStatus;
  source?: EvidenceSource;
}

export interface Product {
  id: string;
  manufacturer: string;
  family: string;
  model: string;
  market: string;
  category: 'COMMERCIAL_DX';
  indoorType: 'DUCTED' | 'CASSETTE';
  application: 'STANDARD_COMMERCIAL' | 'HIGH_SENSIBLE';
  parameters: ProductParameter[];
}

export interface MatchFactor {
  key: string;
  label: string;
  weight: number;
  score: number;
  explanation: string;
}

export interface MatchResult {
  source: Product;
  candidate: Product;
  score: number;
  factors: MatchFactor[];
}
