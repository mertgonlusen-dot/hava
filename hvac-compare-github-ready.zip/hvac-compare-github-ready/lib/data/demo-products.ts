import { Product, ProductParameter } from '@/lib/types';

const src = (id:string, manufacturer:string, page:number) => ({
  id,
  title: `${manufacturer} Technical Data Book — DEMO PLACEHOLDER`,
  manufacturer,
  revision: 'DEMO-2026',
  page,
  note: 'Illustrative source object. Replace with verified public manufacturer documentation.'
});

const p = (key: ProductParameter['key'], label:string, value:number|string|null, unit:string|undefined, page:number, manufacturer:string, condition?:string): ProductParameter => ({
  key,label,value,unit,condition,status:value === null ? 'UNKNOWN':'VERIFIED',source:value === null ? undefined : src(`${manufacturer}-${page}`,manufacturer,page)
});

export const demoProducts: Product[] = [
  {
    id:'d-rzag100-fba100', manufacturer:'Daikin', family:'Sky Air Alpha', model:'RZAG100 + FBA100', market:'EU', category:'COMMERCIAL_DX', indoorType:'DUCTED', application:'HIGH_SENSIBLE',
    parameters:[
      p('nominal_cooling_kw','Nominal cooling',9.5,'kW',101,'Daikin','Rated condition — demo'),
      p('nominal_heating_kw','Nominal heating',10.8,'kW',101,'Daikin','Rated condition — demo'),
      p('seer','SEER',6.4,undefined,104,'Daikin'), p('scop','SCOP',4.5,undefined,104,'Daikin'),
      p('heating_min_ambient_c','Heating min ambient',-20,'°C',117,'Daikin'), p('cooling_max_ambient_c','Cooling max ambient',52,'°C',117,'Daikin'),
      p('max_piping_m','Max piping',85,'m',121,'Daikin'), p('sound_power_dba','Outdoor sound power',66,'dBA',111,'Daikin'),
      p('refrigerant','Refrigerant','R32',undefined,99,'Daikin'), p('power_supply','Power supply','3N~ 400 V',undefined,109,'Daikin'), p('max_esp_pa','Max ESP',200,'Pa',141,'Daikin')
    ]
  },
  {
    id:'d-rzag125-fba125', manufacturer:'Daikin', family:'Sky Air Alpha', model:'RZAG125 + FBA125', market:'EU', category:'COMMERCIAL_DX', indoorType:'DUCTED', application:'HIGH_SENSIBLE',
    parameters:[p('nominal_cooling_kw','Nominal cooling',12.0,'kW',102,'Daikin'),p('nominal_heating_kw','Nominal heating',13.5,'kW',102,'Daikin'),p('seer','SEER',6.1,undefined,104,'Daikin'),p('scop','SCOP',4.4,undefined,104,'Daikin'),p('heating_min_ambient_c','Heating min ambient',-20,'°C',117,'Daikin'),p('cooling_max_ambient_c','Cooling max ambient',52,'°C',117,'Daikin'),p('max_piping_m','Max piping',85,'m',121,'Daikin'),p('sound_power_dba','Outdoor sound power',68,'dBA',111,'Daikin'),p('refrigerant','Refrigerant','R32',undefined,99,'Daikin'),p('power_supply','Power supply','3N~ 400 V',undefined,109,'Daikin'),p('max_esp_pa','Max ESP',200,'Pa',141,'Daikin')]
  },
  {
    id:'s-cdx100-d', manufacturer:'Samsung', family:'Commercial Split Demo', model:'S-COM100 + DUCT100', market:'EU', category:'COMMERCIAL_DX', indoorType:'DUCTED', application:'STANDARD_COMMERCIAL',
    parameters:[p('nominal_cooling_kw','Nominal cooling',10.0,'kW',44,'Samsung'),p('nominal_heating_kw','Nominal heating',11.2,'kW',44,'Samsung'),p('seer','SEER',6.2,undefined,45,'Samsung'),p('scop','SCOP',4.4,undefined,45,'Samsung'),p('heating_min_ambient_c','Heating min ambient',-15,'°C',51,'Samsung'),p('cooling_max_ambient_c','Cooling max ambient',50,'°C',51,'Samsung'),p('max_piping_m','Max piping',75,'m',56,'Samsung'),p('sound_power_dba','Outdoor sound power',67,'dBA',48,'Samsung'),p('refrigerant','Refrigerant','R32',undefined,42,'Samsung'),p('power_supply','Power supply','3N~ 400 V',undefined,47,'Samsung'),p('max_esp_pa','Max ESP',180,'Pa',73,'Samsung')]
  },
  {
    id:'s-cdx120-d', manufacturer:'Samsung', family:'Commercial Split Demo', model:'S-COM120 + DUCT120', market:'EU', category:'COMMERCIAL_DX', indoorType:'DUCTED', application:'STANDARD_COMMERCIAL',
    parameters:[p('nominal_cooling_kw','Nominal cooling',12.0,'kW',44,'Samsung'),p('nominal_heating_kw','Nominal heating',13.2,'kW',44,'Samsung'),p('seer','SEER',5.9,undefined,45,'Samsung'),p('scop','SCOP',4.3,undefined,45,'Samsung'),p('heating_min_ambient_c','Heating min ambient',-15,'°C',51,'Samsung'),p('cooling_max_ambient_c','Cooling max ambient',50,'°C',51,'Samsung'),p('max_piping_m','Max piping',75,'m',56,'Samsung'),p('sound_power_dba','Outdoor sound power',69,'dBA',48,'Samsung'),p('refrigerant','Refrigerant','R32',undefined,42,'Samsung'),p('power_supply','Power supply','3N~ 400 V',undefined,47,'Samsung'),p('max_esp_pa','Max ESP',180,'Pa',73,'Samsung')]
  },
  {
    id:'me-cdx100-d', manufacturer:'Mitsubishi Electric', family:'Mr Slim Demo', model:'ME-COM100 + DUCT100', market:'EU', category:'COMMERCIAL_DX', indoorType:'DUCTED', application:'STANDARD_COMMERCIAL',
    parameters:[p('nominal_cooling_kw','Nominal cooling',10.0,'kW',84,'Mitsubishi Electric'),p('nominal_heating_kw','Nominal heating',11.0,'kW',84,'Mitsubishi Electric'),p('seer','SEER',6.0,undefined,85,'Mitsubishi Electric'),p('scop','SCOP',4.5,undefined,85,'Mitsubishi Electric'),p('heating_min_ambient_c','Heating min ambient',-20,'°C',91,'Mitsubishi Electric'),p('cooling_max_ambient_c','Cooling max ambient',46,'°C',91,'Mitsubishi Electric'),p('max_piping_m','Max piping',75,'m',96,'Mitsubishi Electric'),p('sound_power_dba','Outdoor sound power',66,'dBA',88,'Mitsubishi Electric'),p('refrigerant','Refrigerant','R32',undefined,82,'Mitsubishi Electric'),p('power_supply','Power supply','3N~ 400 V',undefined,87,'Mitsubishi Electric'),p('max_esp_pa','Max ESP',150,'Pa',110,'Mitsubishi Electric')]
  }
];
