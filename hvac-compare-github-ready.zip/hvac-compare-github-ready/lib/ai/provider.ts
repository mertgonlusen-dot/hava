import OpenAI from 'openai';
import { z } from 'zod';

export const ExtractedParameterSchema=z.object({key:z.string(),value:z.union([z.string(),z.number(),z.null()]),unit:z.string().optional(),condition:z.string().optional(),page:z.number().optional(),confidence:z.number().min(0).max(1)});
export type ExtractedParameter=z.infer<typeof ExtractedParameterSchema>;

export interface AiProvider { explainComparison(evidence:unknown):Promise<string>; }

export class OpenAiProvider implements AiProvider {
  private client:OpenAI;
  constructor(){ if(!process.env.OPENAI_API_KEY) throw new Error('OPENAI_API_KEY missing'); this.client=new OpenAI({apiKey:process.env.OPENAI_API_KEY}); }
  async explainComparison(evidence:unknown){
    const response=await this.client.responses.create({model:process.env.OPENAI_MODEL||'gpt-5',input:[{role:'system',content:'You are an HVAC comparison narrator. Use only supplied evidence. Never infer missing technical values. Clearly state unknowns.'},{role:'user',content:JSON.stringify(evidence)}]});
    return response.output_text;
  }
}
