import ExcelJS from 'exceljs';
import { MatchResult } from '@/lib/types';

export async function buildComparisonWorkbook(result:MatchResult) {
  const wb=new ExcelJS.Workbook(); wb.creator='HVAC Compare'; wb.created=new Date();
  const ws=wb.addWorksheet('Comparison');
  ws.columns=[{header:'Parameter',key:'parameter',width:28},{header:result.source.model,key:'source',width:24},{header:result.candidate.model,key:'candidate',width:24},{header:'Condition',key:'condition',width:28},{header:'Status',key:'status',width:15},{header:'Source',key:'evidence',width:42}];
  for(const sp of result.source.parameters){
    const cp=result.candidate.parameters.find(x=>x.key===sp.key);
    ws.addRow({parameter:sp.label,source:sp.value===null?'Unknown':`${sp.value}${sp.unit?` ${sp.unit}`:''}`,candidate:cp?.value===null||cp?.value===undefined?'Unknown':`${cp.value}${cp.unit?` ${cp.unit}`:''}`,condition:sp.condition??cp?.condition??'',status:`${sp.status} / ${cp?.status??'UNKNOWN'}`,evidence:[sp.source&&`${sp.source.title}, p.${sp.source.page}`,cp?.source&&`${cp.source.title}, p.${cp.source.page}`].filter(Boolean).join(' | ')});
  }
  const rs=wb.addWorksheet('Match logic'); rs.columns=[{header:'Factor',key:'factor',width:28},{header:'Weight',key:'weight',width:12},{header:'Score',key:'score',width:12},{header:'Explanation',key:'explanation',width:70}];
  result.factors.forEach(f=>rs.addRow({factor:f.label,weight:f.weight,score:f.score,explanation:f.explanation}));
  rs.addRow({factor:'TOTAL',score:result.score});
  const note=wb.addWorksheet('Read me'); note.getCell('A1').value='IMPORTANT'; note.getCell('A2').value='The bundled MVP demo values are illustrative placeholders. Replace them with verified manufacturer sources before any external use.'; note.getColumn(1).width=110;
  return wb.xlsx.writeBuffer();
}
