export const DEFAULT_WEIGHTS = {
  capacity: 0.22,
  application: 0.15,
  indoorType: 0.12,
  refrigerant: 0.10,
  operatingEnvelope: 0.13,
  efficiency: 0.10,
  piping: 0.06,
  acoustics: 0.05,
  esp: 0.07
} as const;
