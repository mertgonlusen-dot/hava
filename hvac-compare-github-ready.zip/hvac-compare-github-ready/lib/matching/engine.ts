import { demoProducts } from '@/lib/data/demo-products';
import { MatchFactor, MatchResult, Product, ParameterKey } from '@/lib/types';
import { DEFAULT_WEIGHTS } from './rules';

const get = (p: Product, key: ParameterKey) => p.parameters.find(x => x.key === key)?.value ?? null;
const num = (p:Product,key:ParameterKey) => { const v=get(p,key); return typeof v === 'number' ? v : null; };
const text = (p:Product,key:ParameterKey) => { const v=get(p,key); return typeof v === 'string' ? v : null; };
const closeness = (a:number|null,b:number|null,tolerance:number) => {
  if (a === null || b === null) return 0.45;
  if (a === 0 && b === 0) return 1;
  const diff = Math.abs(a-b) / Math.max(Math.abs(a),Math.abs(b),1);
  return Math.max(0, 1 - diff / tolerance);
};

export function eligibleCandidates(source:Product, products:Product[]=demoProducts) {
  const cap = num(source,'nominal_cooling_kw');
  return products.filter(p => {
    if (p.manufacturer === source.manufacturer || p.category !== source.category || p.indoorType !== source.indoorType || p.market !== source.market) return false;
    const c=num(p,'nominal_cooling_kw');
    if (cap === null || c === null) return true;
    return c >= cap*0.8 && c <= cap*1.25;
  });
}

export function scoreMatch(source:Product,candidate:Product):MatchResult {
  const factors:MatchFactor[] = [];
  const add=(key:string,label:string,weight:number,score:number,explanation:string)=>factors.push({key,label,weight,score:Math.round(score*1000)/10,explanation});
  add('capacity','Capacity class',DEFAULT_WEIGHTS.capacity,closeness(num(source,'nominal_cooling_kw'),num(candidate,'nominal_cooling_kw'),0.30),'Nominal cooling capacity proximity.');
  add('application','Application',DEFAULT_WEIGHTS.application,source.application===candidate.application?1:0.65,'Exact application match receives full score; adjacent commercial positioning is penalized.');
  add('indoorType','Indoor type',DEFAULT_WEIGHTS.indoorType,source.indoorType===candidate.indoorType?1:0,'Ducted and cassette products are not treated as direct equivalents.');
  add('refrigerant','Refrigerant',DEFAULT_WEIGHTS.refrigerant,text(source,'refrigerant')===text(candidate,'refrigerant')?1:0.4,'Exact refrigerant match preferred.');
  const heatMin=closeness(num(source,'heating_min_ambient_c'),num(candidate,'heating_min_ambient_c'),0.55);
  const coolMax=closeness(num(source,'cooling_max_ambient_c'),num(candidate,'cooling_max_ambient_c'),0.35);
  add('operatingEnvelope','Operating envelope',DEFAULT_WEIGHTS.operatingEnvelope,(heatMin+coolMax)/2,'Combines published low-ambient heating and high-ambient cooling limits.');
  const seer=closeness(num(source,'seer'),num(candidate,'seer'),0.25); const scop=closeness(num(source,'scop'),num(candidate,'scop'),0.25);
  add('efficiency','Seasonal efficiency',DEFAULT_WEIGHTS.efficiency,(seer+scop)/2,'SEER and SCOP proximity.');
  add('piping','Piping',DEFAULT_WEIGHTS.piping,closeness(num(source,'max_piping_m'),num(candidate,'max_piping_m'),0.45),'Maximum published piping length proximity.');
  add('acoustics','Acoustics',DEFAULT_WEIGHTS.acoustics,closeness(num(source,'sound_power_dba'),num(candidate,'sound_power_dba'),0.20),'Outdoor sound-power proximity.');
  add('esp','External static pressure',DEFAULT_WEIGHTS.esp,closeness(num(source,'max_esp_pa'),num(candidate,'max_esp_pa'),0.50),'Published maximum indoor ESP proximity.');
  const total = factors.reduce((sum,f)=>sum+(f.score/100)*f.weight,0) / factors.reduce((s,f)=>s+f.weight,0);
  return {source,candidate,score:Math.round(total*1000)/10,factors};
}

export function compareProduct(sourceId:string, manufacturer?:string) {
  const source=demoProducts.find(p=>p.id===sourceId); if(!source) throw new Error('Source product not found');
  return eligibleCandidates(source).filter(c=>!manufacturer || c.manufacturer===manufacturer).map(c=>scoreMatch(source,c)).sort((a,b)=>b.score-a.score);
}
