'use client';
import { useMemo, useState } from 'react';
import { demoProducts } from '@/lib/data/demo-products';
import { scoreMatch, eligibleCandidates } from '@/lib/matching/engine';

export default function CompareClient(){
  const sources=demoProducts.filter(p=>p.manufacturer==='Daikin');
  const [sourceId,setSourceId]=useState(sources[0].id); const [manufacturer,setManufacturer]=useState('Samsung');
  const source=demoProducts.find(p=>p.id===sourceId)!;
  const results=useMemo(()=>eligibleCandidates(source).filter(c=>c.manufacturer===manufacturer).map(c=>scoreMatch(source,c)).sort((a,b)=>b.score-a.score),[sourceId,manufacturer]);
  const best=results[0];
  return <>
    <div className="card">
      <div className="formRow">
        <label>Source product<select value={sourceId} onChange={e=>setSourceId(e.target.value)}>{sources.map(p=><option key={p.id} value={p.id}>{p.model}</option>)}</select></label>
        <label>Competitor<select value={manufacturer} onChange={e=>setManufacturer(e.target.value)}><option>Samsung</option><option>Mitsubishi Electric</option></select></label>
        {best && <a className="cta" href={`/api/export?sourceId=${sourceId}&candidateId=${best.candidate.id}`}>Export Excel</a>}
      </div>
    </div>
    {!best ? <div className="notice" style={{marginTop:16}}>No eligible candidate in the demo dataset.</div> : <div className="split" style={{marginTop:16}}>
      <aside className="card"><div className="muted">Closest technical candidate</div><h2 style={{marginTop:8}}>{best.candidate.model}</h2><div className="score">{best.score}<small>%</small></div><p className="muted">Deterministic engineering match score. It is not a claim of product superiority.</p>{best.factors.map(f=><div className="factor" key={f.key}><span>{f.label}</span><div className="bar"><span style={{width:`${f.score}%`}} /></div><strong>{f.score}</strong></div>)}</aside>
      <section className="card"><h2>Evidence-backed comparison</h2><table><thead><tr><th>Parameter</th><th>Daikin</th><th>{manufacturer}</th><th>Evidence status</th></tr></thead><tbody>{source.parameters.map(sp=>{const cp=best.candidate.parameters.find(x=>x.key===sp.key);return <tr key={sp.key}><td><strong>{sp.label}</strong>{sp.condition&&<div className="muted" style={{fontSize:11,marginTop:4}}>{sp.condition}</div>}</td><td>{sp.value===null?'Unknown':`${sp.value}${sp.unit?` ${sp.unit}`:''}`}<div className="muted" style={{fontSize:11,marginTop:4}}>{sp.source?`${sp.source.title} · p.${sp.source.page}`:'No source'}</div></td><td>{cp?.value===null||cp?.value===undefined?'Unknown':`${cp.value}${cp.unit?` ${cp.unit}`:''}`}<div className="muted" style={{fontSize:11,marginTop:4}}>{cp?.source?`${cp.source.title} · p.${cp.source.page}`:'No source'}</div></td><td><span className={`status ${sp.status==='VERIFIED'&&cp?.status==='VERIFIED'?'verified':'unknown'}`}>{sp.status} / {cp?.status??'UNKNOWN'}</span></td></tr>})}</tbody></table></section>
    </div>}
  </>
}
