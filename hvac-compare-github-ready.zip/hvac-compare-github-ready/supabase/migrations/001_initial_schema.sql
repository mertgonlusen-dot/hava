create extension if not exists pgcrypto;

create type verification_status as enum ('VERIFIED','CALCULATED','USER_PROVIDED','INFERRED','UNKNOWN');

create table manufacturers (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  created_at timestamptz not null default now()
);

create table products (
  id uuid primary key default gen_random_uuid(),
  manufacturer_id uuid not null references manufacturers(id),
  family text not null,
  model text not null,
  market text not null,
  category text not null,
  indoor_type text,
  application text,
  lifecycle_status text not null default 'ACTIVE',
  created_at timestamptz not null default now(),
  unique(manufacturer_id, model, market)
);

create table source_documents (
  id uuid primary key default gen_random_uuid(),
  manufacturer_id uuid not null references manufacturers(id),
  title text not null,
  revision text,
  public_url text,
  storage_path text,
  sha256 text,
  publication_date date,
  created_at timestamptz not null default now()
);

create table product_parameters (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references products(id) on delete cascade,
  parameter_key text not null,
  numeric_value numeric,
  text_value text,
  unit text,
  rating_condition jsonb,
  verification verification_status not null default 'UNKNOWN',
  source_document_id uuid references source_documents(id),
  source_page integer,
  source_excerpt text,
  confidence numeric check (confidence is null or confidence between 0 and 1),
  reviewed_by uuid,
  reviewed_at timestamptz,
  created_at timestamptz not null default now()
);

create table comparison_rules (
  id uuid primary key default gen_random_uuid(),
  category text not null,
  rule_key text not null,
  weight numeric not null check (weight >= 0 and weight <= 1),
  config jsonb not null default '{}'::jsonb,
  version integer not null default 1,
  active boolean not null default true
);

create table golden_pairs (
  id uuid primary key default gen_random_uuid(),
  source_product_id uuid not null references products(id),
  target_product_id uuid not null references products(id),
  verdict text not null check (verdict in ('EQUIVALENT','CLOSEST','NOT_EQUIVALENT')),
  rationale text,
  approved_by uuid,
  approved_at timestamptz,
  unique(source_product_id,target_product_id)
);

alter table products enable row level security;
alter table source_documents enable row level security;
alter table product_parameters enable row level security;
